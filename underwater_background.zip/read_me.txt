Hi, I hope you like these assets. You can get more like this from my site www.gamedeveloperstudio.com
If you like them or use them why not consider supporting my site, the more support the more assets I can produce.

for licensing see the Open Game Art license.

This asset comes from a set of three repeating backgrounds- you can check them out here- 

http://www.gamedeveloperstudio.com/graphics/viewgraphic.php?item=19411f5j2a3q1h5v38

Thanks 

Robert Brooks.